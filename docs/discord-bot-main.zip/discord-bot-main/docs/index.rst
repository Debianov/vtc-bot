.. discord-bot documentation master file, created by
   sphinx-quickstart on Fri May 26 17:24:30 2023.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Внутренняя документация проекта "Discord bot".
==============================================

Модуль bot.main
======================
.. automodule:: bot.main
   :members:
   :undoc-members:

Модуль bot.commands
====================
.. automodule:: bot.commands
   :members:
   :undoc-members:

Модуль bot.config
==================
.. automodule:: bot.config
   :members:
   :undoc-members:

Модуль bot.converters
======================
.. automodule:: bot.converters
   :members:
   :undoc-members:

Модуль bot.data
======================
.. automodule:: bot.data
   :members:
   :undoc-members:

Модуль bot.flags
======================
.. automodule:: bot.flags
   :members:
   :undoc-members:

Indices and tables
==================
* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`